package uz.qoriqchi.apk

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF121212)
private val CardBg = Color(0xFF1E1B19)
private val CardBorder = Color(0xFF3A3532)
private val Orange = Color(0xFFFF9800)
private val Green = Color(0xFF00E676)
private val Red = Color(0xFFFF3D57)
private val Muted = Color(0xFFB0B0B0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(1) }
    var result by remember { mutableStateOf<ScanResult?>(null) }
    var scanning by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    fun runScan() {
        if (scanning) return
        scanning = true
        scope.launch {
            result = withContext(Dispatchers.Default) { Scanner.scan(ctx) }
            scanning = false
        }
    }

    LaunchedEffect(Unit) { runScan() }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Header(onSettings = { showSettings = true })
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> AppsScreen(result, scanning)
                1 -> ScanScreen(result, scanning)
                else -> StorageScreen()
            }
        }
        BottomBar(
            selected = tab,
            onSelect = { tab = it },
            onScan = { tab = 1; runScan() },
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Yopish", color = Orange) } },
            title = { Text("Sozlamalar") },
            text = {
                Text(
                    "Apk Qo'riqchi v1.0\n\nTekshiruv faqat qurilmaning o'zida bajariladi, " +
                        "hech qanday ma'lumot internetga yuborilmaydi."
                )
            },
        )
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(vertical = 14.dp)) {
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White)) { append("Apk ") }
                withStyle(SpanStyle(color = Orange)) { append("Qo'riqchi") }
            },
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.Center),
        )
        IconButton(onClick = onSettings, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)) {
            Icon(Icons.Filled.Settings, contentDescription = "Sozlamalar", tint = Muted)
        }
    }
}

// ───────────────────────── Tekshirish ─────────────────────────

@Composable
private fun ScanScreen(result: ScanResult?, scanning: Boolean) {
    val percent = result?.percent ?: 0
    val progress by animateFloatAsState(
        targetValue = if (scanning || result == null) 0f else percent / 100f,
        animationSpec = tween(900),
        label = "progress",
    )
    val ringColor = when {
        scanning || result == null -> Muted
        percent >= 90 -> Green
        percent >= 70 -> Orange
        else -> Red
    }
    val (statusText, statusColor) = when {
        scanning || result == null -> "Tekshirilmoqda..." to Muted
        (result?.dangerous ?: 0) > 0 -> "Xavf aniqlandi" to Red
        (result?.suspicious ?: 0) > 0 -> "Diqqat talab etiladi" to Orange
        else -> "Qurilma xavfsiz" to Green
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .size(250.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF0F3B2A), Color(0xFF061A12)))),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 5.dp.toPx()
                val topLeft = Offset(stroke / 2, stroke / 2)
                val arcSize = Size(size.width - stroke, size.height - stroke)
                drawArc(Color(0x33FFFFFF), -90f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
                drawArc(
                    ringColor, -90f, 360f * progress, false, topLeft, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (scanning || result == null) {
                    CircularProgressIndicator(color = Orange, modifier = Modifier.size(56.dp))
                } else {
                    Icon(Icons.Filled.Shield, null, tint = Orange, modifier = Modifier.size(64.dp))
                }
                Spacer(Modifier.height(10.dp))
                Text("Xavfsizlik tahlili", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                Text(
                    if (scanning || result == null) "..." else "$percent%",
                    color = ringColor, fontSize = 52.sp, fontWeight = FontWeight.Bold,
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        Column(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(36.dp))
                .background(CardBg)
                .border(1.dp, CardBorder, RoundedCornerShape(36.dp))
                .padding(24.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(64.dp).clip(CircleShape).background(Orange.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Shield, null, tint = Orange, modifier = Modifier.size(30.dp)) }
                Spacer(Modifier.size(16.dp))
                Column {
                    Text("Qurilma xavfsizligi holati", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("● $statusText", color = statusColor, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Xavfsizlik bahosi", color = Muted, fontSize = 15.sp)
            Text(
                if (result == null) "—" else "$percent% Xavfsiz",
                color = if (result == null) Muted else statusColor,
                fontSize = 32.sp, fontWeight = FontWeight.Bold,
            )
            Text("${result?.total ?: 0} ta nazorat qilinayotgan ilova", color = Muted, fontSize = 15.sp)
            Spacer(Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatBox(Icons.Filled.Error, result?.dangerous ?: 0, "Xavfli", Red)
                StatBox(Icons.Filled.Warning, result?.suspicious ?: 0, "Shubhali", Orange)
                StatBox(Icons.Filled.CheckCircle, result?.safe ?: 0, "Xavfsiz", Green)
            }
        }
    }
}

@Composable
private fun RowScope.StatBox(icon: ImageVector, count: Int, label: String, color: Color) {
    val shape = RoundedCornerShape(28.dp)
    Column(
        Modifier
            .weight(1f)
            .height(130.dp)
            .clip(shape)
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.3f), shape),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(6.dp))
        Text("$count", color = color, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Muted, fontSize = 13.sp)
    }
}

// ───────────────────────── Ilovalar ─────────────────────────

@Composable
private fun AppsScreen(result: ScanResult?, scanning: Boolean) {
    val ctx = LocalContext.current
    if (result == null || scanning) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Orange)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(result.apps, key = { it.pkg }) { app ->
            val color = when (app.risk) {
                Risk.DANGEROUS -> Red
                Risk.SUSPICIOUS -> Orange
                Risk.SAFE -> Green
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(CardBg)
                    .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                    .clickable {
                        // Ilova sozlamalari (u yerdan o'chirib tashlash mumkin)
                        val intent = Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.pkg}"),
                        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(intent)
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(color))
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(app.pkg, color = Muted, fontSize = 12.sp)
                    if (app.risk != Risk.SAFE) {
                        Text(app.reasons.joinToString(" · "), color = color, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ───────────────────────── Xotira tekshiruvi ─────────────────────────

@Composable
private fun StorageScreen() {
    val ctx = LocalContext.current
    val stat = remember { StatFs(Environment.getDataDirectory().path) }
    val totalDisk = stat.blockCountLong * stat.blockSizeLong
    val freeDisk = stat.availableBlocksLong * stat.blockSizeLong
    val mem = remember {
        ActivityManager.MemoryInfo().also {
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        MemoryCard(ctx, "Doimiy xotira", totalDisk, totalDisk - freeDisk)
        MemoryCard(ctx, "Operativ xotira (RAM)", mem.totalMem, mem.totalMem - mem.availMem)
    }
}

@Composable
private fun MemoryCard(ctx: Context, title: String, total: Long, used: Long) {
    val fraction = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    val color = when {
        fraction > 0.9f -> Red
        fraction > 0.75f -> Orange
        else -> Green
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(CardBg)
            .border(1.dp, CardBorder, RoundedCornerShape(28.dp))
            .padding(22.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Storage, null, tint = Orange)
            Spacer(Modifier.size(12.dp))
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
            color = color,
            trackColor = Color(0x33FFFFFF),
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Band: ${Formatter.formatFileSize(ctx, used)} / ${Formatter.formatFileSize(ctx, total)}",
            color = Color.White, fontSize = 15.sp,
        )
        Text(
            "Bo'sh: ${Formatter.formatFileSize(ctx, total - used)} (${(fraction * 100).toInt()}% band)",
            color = Muted, fontSize = 14.sp,
        )
    }
}

// ───────────────────────── Pastki panel ─────────────────────────

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit, onScan: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
            .background(Color(0xFF1C1C1C))
            .padding(top = 8.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        BarItem(Icons.Filled.Apps, "Ilovalar", selected == 0) { onSelect(0) }
        Column(
            Modifier.weight(1f).clickable { onScan() },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFFFF9800), Color(0xFFFF6A00)))),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Shield, null, tint = Color.White, modifier = Modifier.size(38.dp)) }
            Text(
                "Tekshirish",
                color = Orange, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        BarItem(Icons.Filled.Storage, "Xotira tekshiruvi", selected == 2) { onSelect(2) }
    }
}

@Composable
private fun RowScope.BarItem(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = if (active) Orange else Muted, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (active) Orange else Color.White, fontSize = 14.sp)
    }
}
