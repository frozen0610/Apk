package uz.qoriqchi.apk

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

enum class Risk { SAFE, SUSPICIOUS, DANGEROUS }

data class AppEntry(
    val label: String,
    val pkg: String,
    val risk: Risk,
    val reasons: List<String>,
)

data class ScanResult(val apps: List<AppEntry>) {
    val total: Int get() = apps.size
    val dangerous: Int get() = apps.count { it.risk == Risk.DANGEROUS }
    val suspicious: Int get() = apps.count { it.risk == Risk.SUSPICIOUS }
    val safe: Int get() = apps.count { it.risk == Risk.SAFE }
    val percent: Int get() = if (total == 0) 100 else Math.round(safe * 100f / total)
}

/**
 * Oddiy evristik tahlil (hech narsa tarmoqqa yuborilmaydi):
 *  - tizim ilovalari xavfsiz hisoblanadi;
 *  - boshqa ilovalar uchun xavfli ruxsatlar va o'rnatilgan manba bo'yicha ball hisoblanadi.
 */
object Scanner {

    private val trustedInstallers = setOf(
        "com.android.vending",
        "com.sec.android.app.samsungapps",
        "com.xiaomi.mipicks",
        "com.huawei.appmarket",
        "com.amazon.venezia",
        "com.heytap.market",
        "com.oppo.market",
        "com.vivo.appstore",
    )

    private val permissionRisk: Map<String, Pair<String, Int>> = mapOf(
        "android.permission.READ_SMS" to ("SMS o'qiydi" to 2),
        "android.permission.RECEIVE_SMS" to ("SMS qabul qiladi" to 2),
        "android.permission.SEND_SMS" to ("SMS yuboradi" to 2),
        "android.permission.READ_CALL_LOG" to ("Qo'ng'iroqlar tarixi" to 1),
        "android.permission.RECORD_AUDIO" to ("Mikrofon" to 1),
        "android.permission.READ_CONTACTS" to ("Kontaktlar" to 1),
        "android.permission.SYSTEM_ALERT_WINDOW" to ("Boshqa ilovalar ustida chizadi" to 2),
        "android.permission.REQUEST_INSTALL_PACKAGES" to ("Ilova o'rnata oladi" to 1),
        "android.permission.BIND_DEVICE_ADMIN" to ("Qurilma administratori" to 3),
    )

    private const val ACCESSIBILITY_PERMISSION = "android.permission.BIND_ACCESSIBILITY_SERVICE"

    fun scan(ctx: Context): ScanResult {
        val pm = ctx.packageManager
        val entries = installedApps(pm)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { analyze(pm, it) }
        val sorted = entries.sortedWith(
            compareByDescending<AppEntry> { it.risk.ordinal }.thenBy { it.label.lowercase() }
        )
        return ScanResult(sorted)
    }

    @Suppress("DEPRECATION")
    private fun installedApps(pm: PackageManager): List<ApplicationInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            pm.getInstalledApplications(0)
        }

    @Suppress("DEPRECATION")
    private fun packageInfo(pm: PackageManager, pkg: String): PackageInfo? = try {
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            pm.getPackageInfo(pkg, flags)
        }
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) {
            pm.getInstallSourceInfo(pkg).installingPackageName
        } else {
            pm.getInstallerPackageName(pkg)
        }
    } catch (e: Exception) {
        null
    }

    private fun analyze(pm: PackageManager, ai: ApplicationInfo): AppEntry {
        val label = ai.loadLabel(pm).toString()
        val pkg = ai.packageName
        val isSystem = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
        if (isSystem) return AppEntry(label, pkg, Risk.SAFE, listOf("Tizim ilovasi"))

        var score = 0
        val reasons = mutableListOf<String>()
        val info = packageInfo(pm, pkg)

        info?.requestedPermissions?.forEach { perm ->
            permissionRisk[perm]?.let { (name, weight) ->
                score += weight
                reasons += name
            }
        }
        if (info?.services?.any { it.permission == ACCESSIBILITY_PERMISSION } == true) {
            score += 3
            reasons += "Maxsus imkoniyatlar xizmati"
        }
        val source = installer(pm, pkg)
        if (source == null || source !in trustedInstallers) {
            score += 2
            reasons += "Ishonchli do'kondan o'rnatilmagan"
        }

        val risk = when {
            score >= 6 -> Risk.DANGEROUS
            score >= 3 -> Risk.SUSPICIOUS
            else -> Risk.SAFE
        }
        if (reasons.isEmpty()) reasons += "Xavf aniqlanmadi"
        return AppEntry(label, pkg, risk, reasons.distinct())
    }
}
